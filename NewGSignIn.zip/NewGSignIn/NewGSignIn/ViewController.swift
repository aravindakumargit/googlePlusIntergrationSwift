//
//  ViewController.swift
//  NewGSignIn
//
//  Created by cricket21 on 10/05/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

import UIKit
import Google
import GoogleSignIn
class ViewController: UIViewController,GIDSignInUIDelegate,GIDSignInDelegate {
    
    @IBOutlet var ImgView: UIImageView!
    @IBOutlet var lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var error: NSError?
        GGLContext.sharedInstance().configureWithError(&error)
        if error != nil{
            print(error)
            return
        }
        GIDSignIn.sharedInstance().uiDelegate=self
        GIDSignIn.sharedInstance().delegate=self
        let signInButton=GIDSignInButton()
        signInButton.center=view.center
        view.addSubview(signInButton)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
   
    func sign(inWillDispatch signIn: GIDSignIn!, error: Error!) {
        //myActivityIndicator.stopAnimating()
    }
    
    // Present a view that prompts the user to sign in with Google
    func sign(_ signIn: GIDSignIn!,
              present viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    func sign(_ signIn: GIDSignIn!,
              dismiss viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
    }
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if (error == nil) {
            print("the user is \(user.profile.imageURL(withDimension: 200))")
            var imgUrl = NSString()
            imgUrl = user.profile.imageURL(withDimension: 200) as! NSString
            print(imgUrl)
            
            let url = NSURL(string: imgUrl as String)
            let datas = NSData(contentsOf: url as! URL)
            self.ImgView.image = UIImage(data: datas as! Data)
            // Perform any operations on signed in user here.
            let userId = user.userID
            let idToken = user.authentication.idToken
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
            self.lbl.text=user.profile.email
        } else {
            print("\(error.localizedDescription)")
        }
    }

}

