//
//  Bridging-Header.h
//  facebookIn
//
//  Created by cricket21 on 06/05/17.
//  Copyright © 2017 cricket21. All rights reserved.
//
#define Bridging_Header_h
#ifndef NewGSignIn_Bridging_Header_h
#define NewGSignIn_Bridging_Header_h
#import <Google/SignIn.h>
#import "GoogleSignIn/GoogleSignIn.h"


#endif /* Bridging_Header_h */
